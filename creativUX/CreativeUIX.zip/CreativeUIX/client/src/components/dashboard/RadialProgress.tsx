import { cn } from "@/lib/utils";

interface RadialProgressProps {
  value: number;
  label: string;
  sublabel: string;
  className?: string;
}

export function RadialProgress({ value, label, sublabel, className }: RadialProgressProps) {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className={cn("relative flex flex-col items-center justify-center", className)}>
      <div className="relative w-32 h-16 overflow-hidden">
         {/* Background Arc */}
        <svg className="absolute top-0 left-0 w-full h-full overflow-visible" viewBox="0 0 100 50">
           <path
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke="#f1f5f9"
            strokeWidth="8"
            strokeLinecap="round"
          />
          {/* Foreground Arc */}
          <path
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke="url(#radialGradient)"
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={Math.PI * 80} // Approx circumference for semi-circle
            strokeDashoffset={Math.PI * 80 * (1 - value/100)}
            className="transition-all duration-1000 ease-out"
          />
           <defs>
            <linearGradient id="radialGradient" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#84cc16" />
              <stop offset="100%" stopColor="#3b82f6" />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 text-center">
            <span className="text-2xl font-bold">{value}%</span>
        </div>
      </div>
      <div className="text-center mt-2">
        <div className="text-xs font-medium text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}
