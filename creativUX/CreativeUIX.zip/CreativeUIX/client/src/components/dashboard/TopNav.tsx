import { cn } from "@/lib/utils";
import { Search, Bell, User, Store, LayoutGrid, Settings, Calendar, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function TopNav() {
  return (
    <div className="w-full flex items-center justify-between py-6">
        {/* Left Side: Brand & Nav */}
        <div className="flex items-center gap-12">
            <div className="flex items-center gap-2 font-bold text-xl">
                <div className="w-8 h-8 bg-black rounded-full flex items-center justify-center text-white">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                    </svg>
                </div>
                Trivia
            </div>

            <nav className="hidden md:flex items-center bg-white rounded-full px-2 py-1.5 shadow-sm border border-slate-100">
                <Button variant="ghost" className="rounded-full bg-black text-white hover:bg-black/90 px-6 h-9 text-sm font-medium">Home</Button>
                <Button variant="ghost" className="rounded-full text-muted-foreground hover:text-foreground px-6 h-9 text-sm font-medium">Sell</Button>
                <Button variant="ghost" className="rounded-full text-muted-foreground hover:text-foreground px-6 h-9 text-sm font-medium">Sales</Button>
                <Button variant="ghost" className="rounded-full text-muted-foreground hover:text-foreground px-6 h-9 text-sm font-medium">Inventory</Button>
                <Button variant="ghost" className="rounded-full text-muted-foreground hover:text-foreground px-6 h-9 text-sm font-medium">Customers</Button>
                <Button variant="ghost" className="rounded-full text-muted-foreground hover:text-foreground px-6 h-9 text-sm font-medium">Report</Button>
            </nav>
        </div>

        {/* Right Side: Search & Profile */}
        <div className="flex items-center gap-4">
            <div className="relative hidden lg:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input 
                    type="text" 
                    placeholder="Search" 
                    className="h-10 pl-10 pr-4 rounded-full bg-white border-none shadow-sm w-[240px] text-sm focus:outline-none focus:ring-2 focus:ring-slate-200"
                />
            </div>
            <Button size="icon" variant="ghost" className="rounded-full bg-white hover:bg-slate-50 shadow-sm">
                <Bell className="w-4 h-4 text-slate-600" />
            </Button>
            <Avatar className="w-10 h-10 border-2 border-white shadow-sm">
                <AvatarImage src="https://github.com/shadcn.png" />
                <AvatarFallback>UD</AvatarFallback>
            </Avatar>
        </div>
    </div>
  );
}

export function SideNav() {
    return (
        <div className="hidden lg:flex flex-col items-center gap-4 py-4 w-16">
             <Button size="icon" variant="ghost" className="w-10 h-10 rounded-xl bg-white shadow-sm hover:bg-slate-50 text-slate-600">
                <LayoutGrid className="w-5 h-5" />
            </Button>
             <Button size="icon" variant="ghost" className="w-10 h-10 rounded-xl hover:bg-white/50 text-slate-400 hover:text-slate-600">
                <ShoppingBag className="w-5 h-5" />
            </Button>
             <Button size="icon" variant="ghost" className="w-10 h-10 rounded-xl hover:bg-white/50 text-slate-400 hover:text-slate-600">
                <Calendar className="w-5 h-5" />
            </Button>
            <Button size="icon" variant="ghost" className="w-10 h-10 rounded-xl hover:bg-white/50 text-slate-400 hover:text-slate-600">
                <User className="w-5 h-5" />
            </Button>
             <Button size="icon" variant="ghost" className="w-10 h-10 rounded-xl hover:bg-white/50 text-slate-400 hover:text-slate-600 mt-auto">
                <Settings className="w-5 h-5" />
            </Button>
        </div>
    )
}
