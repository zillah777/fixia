import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string;
  subtext: string;
  trend?: "up" | "down";
  trendValue?: string;
  className?: string;
}

export function StatsCard({ title, value, subtext, trend, trendValue, className }: StatsCardProps) {
  return (
    <Card className={cn("border-none shadow-none bg-white card-soft-shadow rounded-3xl overflow-hidden", className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline justify-between">
          <div className="text-3xl font-bold text-foreground tracking-tight">{value}</div>
        </div>
        <div className="mt-4 flex items-center gap-2">
            {trend === "up" && (
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-100 text-green-600">
                    <ArrowUpRight className="h-4 w-4" />
                </div>
            )}
            {trend === "down" && (
                 <div className="flex items-center justify-center w-8 h-8 rounded-full bg-red-100 text-red-600">
                    <ArrowDownRight className="h-4 w-4" />
                </div>
            )}
            <p className="text-xs text-muted-foreground font-medium">
                {subtext}
            </p>
        </div>
        {/* Mini chart area could go here */}
      </CardContent>
    </Card>
  );
}
