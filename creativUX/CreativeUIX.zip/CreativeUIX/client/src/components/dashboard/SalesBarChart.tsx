import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Cell } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowUpRight } from "lucide-react";

const data = [
  { name: "Sep", total: 2500 },
  { name: "Oct", total: 5500 }, // Highlighted
  { name: "Nov", total: 3000 },
];

export function SalesBarChart() {
  return (
    <Card className="border-none shadow-none bg-white card-soft-shadow rounded-3xl h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
            <CardTitle className="text-lg font-bold text-foreground">Sales Statistics</CardTitle>
            <div className="flex gap-4 mt-2 text-xs font-medium text-muted-foreground">
                <span>Correction Needed</span>
                <span className="text-foreground font-bold">New Record</span>
            </div>
        </div>
        
      </CardHeader>
      <CardContent className="pt-4">
        <div className="mb-8 flex items-center gap-4">
            <div className="p-3 bg-blue-50 rounded-2xl text-blue-600">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 3V21H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M18 9L13.875 13.125L10.125 9.375L7 12.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
            </div>
            <div>
                <div className="text-3xl font-bold">826 <span className="text-sm bg-green-100 text-green-700 px-2 py-1 rounded-full ml-2">+51.34%</span></div>
                <div className="text-xs text-muted-foreground mt-1">New Leads This Month</div>
            </div>
            <button className="ml-auto w-10 h-10 rounded-full border flex items-center justify-center hover:bg-slate-50">
                <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
            </button>
        </div>

        <div className="h-[200px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} barSize={60}>
                <defs>
                    <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#10b981" />
                    </linearGradient>
                    <linearGradient id="colorLight" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#dcfce7" />
                        <stop offset="100%" stopColor="#d1fae5" />
                    </linearGradient>
                </defs>
              <XAxis 
                dataKey="name" 
                stroke="#888888" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false}
                dy={10}
              />
              <YAxis
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `$${value}`}
              />
              <Tooltip 
                cursor={{fill: 'transparent'}}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}
              />
              <Bar dataKey="total" radius={[4, 4, 0, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === 1 ? "url(#colorGradient)" : "url(#colorLight)"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
