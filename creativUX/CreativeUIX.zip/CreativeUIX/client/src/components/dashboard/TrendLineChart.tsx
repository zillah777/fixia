import { Line, LineChart, ResponsiveContainer, Tooltip } from "recharts";

const data = [
  { value: 40 },
  { value: 30 },
  { value: 45 },
  { value: 35 },
  { value: 55 },
  { value: 40 },
  { value: 50 },
];

export function TrendLineChart() {
  return (
    <div className="h-[60px] w-full mt-2">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
            <defs>
                <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#3b82f6" />
                    <stop offset="50%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
            </defs>
          <Tooltip 
            contentStyle={{ borderRadius: '8px', border: 'none', padding: '4px 8px', fontSize: '12px' }}
            cursor={{ stroke: '#e2e8f0' }}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="url(#lineGradient)"
            strokeWidth={3}
            dot={false}
            activeDot={{ r: 4, strokeWidth: 0, fill: "#3b82f6" }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
