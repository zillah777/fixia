import { cn } from "@/lib/utils";
import windbreakerImage from '@assets/generated_images/urban_tech_streetwear_windbreaker_fashion_shot.png';
import { ArrowUpRight } from "lucide-react";

export function ProductCard() {
  return (
    <div className="relative w-full h-full min-h-[400px] rounded-3xl overflow-hidden group">
        {/* Background Image */}
        <div className="absolute inset-0">
            <img 
                src={windbreakerImage} 
                alt="Urban Tech Windbreaker" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
        </div>

        {/* Glass Overlay Card */}
        <div className="absolute bottom-4 left-4 right-4 glass-panel rounded-2xl p-5 text-white">
            <div className="flex items-center gap-2 mb-2">
                <span className="bg-white/20 backdrop-blur-md px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border border-white/10">
                    Insight
                </span>
            </div>
            <h3 className="text-xl font-bold mb-2">Urban Tech Windbreaker</h3>
            <p className="text-sm text-white/80 leading-relaxed mb-4">
                Our top-selling streetwear piece, loved by 9.8K returning customers for its sleek, weatherproof design and lightweight comfort.
            </p>
        </div>
    </div>
  );
}
