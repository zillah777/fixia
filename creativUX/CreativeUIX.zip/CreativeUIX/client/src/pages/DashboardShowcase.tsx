import { TopNav, SideNav } from "@/components/dashboard/TopNav";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { SalesBarChart } from "@/components/dashboard/SalesBarChart";
import { TrendLineChart } from "@/components/dashboard/TrendLineChart";
import { RadialProgress } from "@/components/dashboard/RadialProgress";
import { ProductCard } from "@/components/dashboard/ProductCard";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";

export default function DashboardShowcase() {
  return (
    <div className="min-h-screen bg-[#F8F9FB] p-4 md:p-8 font-sans text-slate-900">
      <div className="max-w-[1600px] mx-auto">
        <TopNav />

        <div className="flex gap-6 mt-4">
           {/* Side Menu */}
           <SideNav />

           {/* Main Content */}
           <div className="flex-1">
                {/* Welcome Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Hi Daniel, Welcome Back!</h1>
                        <p className="text-muted-foreground mt-1">
                            this month stores have sold <span className="text-blue-600 font-bold text-lg">$331,224.74</span>
                        </p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                        <Button variant="outline" className="rounded-full bg-white border-none shadow-sm h-10 px-4 text-sm font-medium">
                            All Stores <ChevronDown className="ml-2 w-4 h-4" />
                        </Button>
                        
                        <div className="bg-white rounded-full p-1 shadow-sm flex">
                            <Button variant="ghost" className="rounded-full bg-black text-white hover:bg-black/90 h-8 px-4 text-xs font-medium">Today</Button>
                            <Button variant="ghost" className="rounded-full text-muted-foreground hover:text-foreground h-8 px-4 text-xs font-medium">Week</Button>
                            <Button variant="ghost" className="rounded-full text-muted-foreground hover:text-foreground h-8 px-4 text-xs font-medium">Month</Button>
                        </div>
                    </div>
                </div>

                {/* Dashboard Grid */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                    
                    {/* Left Column - Product Highlight */}
                    <div className="md:col-span-4 lg:col-span-3 xl:col-span-3 h-[450px]">
                        <ProductCard />
                    </div>

                    {/* Middle Column - Main Chart & Returning Rate */}
                    <div className="md:col-span-8 lg:col-span-6 xl:col-span-6 flex flex-col gap-6">
                        <div className="flex-1 min-h-[300px]">
                             <SalesBarChart />
                        </div>
                         <div className="grid grid-cols-2 gap-6">
                             {/* Returning Customer Rate */}
                            <div className="bg-white rounded-3xl p-6 card-soft-shadow flex flex-col justify-between">
                                <div className="flex items-start gap-3">
                                    <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>
                                    </div>
                                    <div>
                                        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Returning Customer Rate</h3>
                                    </div>
                                </div>
                                <div className="mt-4">
                                    <div className="text-3xl font-bold">68%</div>
                                    <div className="text-xs text-blue-600 font-medium mt-1">+5.3% increase from last month</div>
                                </div>
                            </div>

                             {/* Sales Store Target */}
                             <div className="bg-white rounded-3xl p-6 card-soft-shadow flex flex-col justify-between">
                                 <h3 className="text-sm font-bold">Sales store target $ 30,250.00</h3>
                                 <div className="mt-4">
                                     <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                                         <div className="h-full w-[75%] bg-gradient-to-r from-blue-500 to-green-400 rounded-full" />
                                     </div>
                                     <div className="text-xs text-muted-foreground mt-2 font-medium">$5,412.44 Left</div>
                                 </div>
                             </div>
                         </div>
                    </div>

                    {/* Right Column - Stats */}
                    <div className="md:col-span-12 lg:col-span-3 xl:col-span-3 flex flex-col gap-6">
                        
                        {/* Average Sale */}
                        <StatsCard 
                            title="Average Sale" 
                            value="3.7 qnt." 
                            subtext="0.41 less than last month" 
                            className="h-auto p-2"
                        />
                        <div className="bg-white rounded-3xl p-6 card-soft-shadow -mt-2">
                             <TrendLineChart />
                              <div className="flex justify-between text-xs text-muted-foreground mt-2 px-2">
                                <span>Mon</span>
                                <span>Sun</span>
                            </div>
                        </div>

                        {/* Total Sale Value */}
                        <div className="bg-white rounded-3xl p-6 card-soft-shadow">
                             <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">Total Sale Value</h3>
                             <div className="text-3xl font-bold mb-1">$ 414.41</div>
                             <div className="text-xs text-muted-foreground mb-4">$0.25 less than last month</div>
                             
                             {/* Custom Bar visualization */}
                             <div className="flex gap-0.5 h-8 items-end">
                                {[...Array(20)].map((_, i) => (
                                    <div 
                                        key={i} 
                                        className="flex-1 bg-gradient-to-t from-blue-500 to-cyan-300 rounded-t-sm opacity-80 hover:opacity-100 transition-opacity"
                                        style={{ height: `${Math.random() * 80 + 20}%` }}
                                    />
                                ))}
                             </div>
                             <div className="flex justify-between text-xs text-muted-foreground mt-2">
                                <span>Mon</span>
                                <span>Sun</span>
                            </div>
                        </div>

                         {/* Total Profit */}
                        <div className="bg-white rounded-3xl p-6 card-soft-shadow">
                             <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-4">Total Profit</h3>
                             <div className="flex justify-between items-end mb-4">
                                 <div>
                                     <div className="text-sm font-bold">$177,349.50</div>
                                     <div className="text-[10px] text-muted-foreground">This month</div>
                                 </div>
                                 <div className="text-right">
                                     <div className="text-sm font-bold">$129,182.90</div>
                                     <div className="text-[10px] text-muted-foreground">Last month</div>
                                 </div>
                             </div>
                             <RadialProgress value={76} label="Goal achieved" sublabel="" />
                        </div>

                    </div>
                </div>
           </div>
        </div>
      </div>
    </div>
  );
}
